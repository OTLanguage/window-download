package sun.util.resources;

import java.util.ListResourceBundle;

public final class LocaleNames_en extends sun.util.resources.LocaleNamesBundle {
    protected final Object[][] getContents() {
        return new Object[][] {
        };
    }
}
